package com.example.aleatorios;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;
import java.util.Scanner;

import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText tn=(EditText)findViewById(R.id.aleatorio);
        final TextView impresor=(TextView) findViewById(R.id.imprimir);
        final Button generar = (Button)findViewById(R.id.generador);

       generar.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
if (generar==view) {
    Random r = new Random();
    int ntotal;
    String nt = tn.getText().toString();
    ntotal = Integer.parseInt(nt);


    for (int i = 0; i < ntotal; i = ntotal) {
        int random = r.nextInt(ntotal) + 1;
        System.out.println(random);
        String randomString = Integer.toString(random);
        impresor.setText(randomString);

    }
}

          }
      });

    }
}